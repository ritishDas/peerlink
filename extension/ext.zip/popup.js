console.log("popup script");

browser.windows.create({
  url: "https://peer-b469f.web.app",
  type: "normal", // can be "normal", "popup", or "panel"
});
